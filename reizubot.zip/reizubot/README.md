## ODADING-BOT
BOT WHATSAPP YANG BISA DIGUNAKAN DI TERMUX


<img src = "https://i.pinimg.com//originals//f6//dc//a0//f6dca0d9666923690c8ad3d53e9f005e.jpg" width="320">




## CARA INSTALL
# TERMUX
```bash
> download termux
> buka
> pkg install git
> pkg install ffmpeg
> pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/aditiapribadiansyah/Odading-BOT
> cd Odading-BOT
> bash install.sh
> node index.js
```


# FITUR

| KEADAAN       |               FITUR     |
| :-----------: | :--------------------------------:  |
|       ✅       |    PANTUN                         |
|       ✅       | ANIME                             |
|       ✅       | STIKER                            |
|       ✅       | NULIS                             |
|       ✅       | QUOTES                            |
|       ✅       | RANDOM PICT                       |
|       ✅       | LIRIK                             |
|       ✅       | ALAY                              |
|       ✅       | YT,YTMP3,IG,TWT DOWNLOADER        |
|       ✅       | WIKIPEDIA                         |
|       ✅       | ARTI NAMA                         |
|       ✅       | SHOLAT                            |
|       ✅       | QURAN                             |
|       ✅       | POKEMON                           |
|       ✅       | LOLI                              |
|       ✅       | KAMING SUN                        |

ket : ✅ : aktif




## THANKS TO
* [`termux-whatsapp-bot`](https://github.com/fdciabdul/termux-whatsapp-bot)
* [`botst4rz`](https://github.com/Bintang73/botst4rz)
## DONASI
via pulsa 081220595591
